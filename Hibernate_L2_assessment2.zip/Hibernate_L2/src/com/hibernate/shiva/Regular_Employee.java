package com.hibernate.shiva;

public class Regular_Employee extends Employeepojo {

	private int qplc;

	public int getQplc() {
		return qplc;
	}

	public void setQplc(int qplc) {
		this.qplc = qplc;
	}
}
