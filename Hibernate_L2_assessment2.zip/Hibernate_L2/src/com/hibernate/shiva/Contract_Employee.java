package com.hibernate.shiva;

      
public class Contract_Employee extends Employeepojo {
	
	private int allowance;

	public int getAllowance() {
		return allowance;
	}

	public void setAllowance(int allowance) {
		this.allowance = allowance;
	}
}
