package com.hibernate.shiva;


import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ClientPrgrm {

	public static void main(String[] args) {
		//AnnotationConfiguration  cfg = new AnnotationConfiguration();
	
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml"); 
		
		SessionFactory factory = cfg.buildSessionFactory();
		
		Session session = factory.openSession();
		
		
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		
		while(flag){
			
			System.out.println("********1.Add Employee****");
			System.out.println("********2.Exit****");
			System.out.println("********3.Batch Processing****");
			System.out.println("********4.Retrieve & display the employee objects whose salary is in between 10000 and 40000****");
			System.out.println("********5.display the employee objects whose name is ending with letter �r / R�****");
			System.out.println("********6.Display last 10 employees�****");
			
			String choice=sc.nextLine();
			
			switch (choice) {
			case "1":
				createuser(session,sc);
				break;
				
			case "2":
				flag=false;
				System.out.println("Program Exit....");
				break;	
				
			case "3":
				batchprocess(session);
				break;
				
			case "4":
				retrive(session);
				break;
				
			case "5":
				Displayname(session);
				break;
				
			case "6":
				Displaylastname(session);
				break;

			default:
				break;
			}
			
		}
		factory.close();

	}
	
	public static void createuser(Session session, Scanner sc){

		Employeepojo e=new Employeepojo(); 
		System.out.println("Enter Employee Name:");
		e.setEmpName(sc.nextLine());
		System.out.println("Enter Employee Salary:");
		e.setEmpSalary(sc.nextInt());
		System.out.println("Enter Employee Age:");
		e.setEmpAge(sc.nextInt());
		System.out.println("Enter Employee Designation:");
		e.setEmpDesignation(sc.nextLine());
		System.out.println("Enter Employee DOB:");
		e.setEmpDOB(sc.nextLine());
		System.out.println("Enter Employee DOJ:");
		e.setEmpDOJ(sc.nextLine());
		Transaction tx = session.beginTransaction();
		session.save(e);
		//session.save(e2);
		tx.commit();
		

	}
	
	
	public static void batchprocess(Session session){
		
		 try {
			 Transaction tx = session.beginTransaction();
	         for ( int i=0; i<50; i++ ) {
	            String fname = "Sivatest " + i;
	            //Employee employee = new Employee(fname, lname, salary);
	            Employeepojo e=new Employeepojo(fname,"Proj.Eng","11-08-1994","11-08-2008",25,250000); 
	            session.save(e);
	         	if( i % 10 == 0 ) {
	               session.flush();
	               session.clear();
	            }
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         e.printStackTrace(); 
	      } finally {
	         
	      }
		
	}
	
	public static void retrive(Session session){
	
   String hql = "from Employeepojo where Empsalary >= 10000 or Empsalary <= 40000";
	org.hibernate.Query qry =  session.createQuery(hql);
	
    //qry.setParameter("min",10000f);
    //qry.setParameter("max",40000f);

	List l =qry.list();
	System.out.println("Total Number Of Records : "+l.size());
	Iterator it = l.iterator();

	while(it.hasNext())
	{
		Object o = (Object) it.next();
		Employeepojo p = (Employeepojo)o;
		System.out.println("Employee Name : "+p.getEmpName());
		System.out.println("---------------------------");
		
	}}
	
	public static void Displayname(Session session){
		
		String hql = "from Employeepojo where EmpName like :keyword or EmpName like :keyword2";
		 
		String keyword = "r";
		String keyword2 = "R";
		
		org.hibernate.Query query =  session.createQuery(hql);
		query.setParameter("keyword", "%" + keyword);
		query.setParameter("keyword2", "%" + keyword2);
		 
		List<Employeepojo> listProducts = query.list();
		 
		for (Employeepojo aProduct : listProducts) {
		    System.out.println(aProduct.getEmpName());
		}
		
	}
	
public static void Displaylastname(Session session){
		
		String hql = "from Employeepojo ORDER BY EmpCode DESC";
		
		org.hibernate.Query query =  session.createQuery(hql);
		query.setFirstResult(0);
		query.setMaxResults(10);
		
		List<Employeepojo> listProducts = query.list();
		for (Employeepojo aProduct : listProducts) {
		    System.out.println(aProduct.getEmpName());
		}
		
	}
	

}
