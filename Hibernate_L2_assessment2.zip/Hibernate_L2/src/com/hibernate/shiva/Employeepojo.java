package com.hibernate.shiva;



public class Employeepojo {
	
	private int Empcode;
	private String EmpName;
	private String EmpDesignation;
	private String EmpDOB;
	private String EmpDOJ;
	private int EmpAge;
	private float EmpSalary;
	
	public Employeepojo(){
		
	}
	
	public Employeepojo (String EmpName,String EmpDesignation,String EmpDOB,String EmpDOJ,int EmpAge,int EmpSalary){
		this.EmpName=EmpName;
		this.EmpAge=EmpAge;
		this.EmpDesignation=EmpDesignation;
		this.EmpDOB=EmpDOB;
		this.EmpDOJ=EmpDOJ;
		this.EmpSalary=EmpSalary;
	}
	
	
	public int getEmpcode() {
		return Empcode;
	}
	public void setEmpcode(int empcode) {
		Empcode = empcode;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getEmpDesignation() {
		return EmpDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		EmpDesignation = empDesignation;
	}
	public String getEmpDOB() {
		return EmpDOB;
	}
	public void setEmpDOB(String empDOB) {
		EmpDOB = empDOB;
	}
	public String getEmpDOJ() {
		return EmpDOJ;
	}
	public void setEmpDOJ(String empDOJ) {
		EmpDOJ = empDOJ;
	}
	public int getEmpAge() {
		return EmpAge;
	}
	public void setEmpAge(int empAge) {
		EmpAge = empAge;
	}
	public float getEmpSalary() {
		return EmpSalary;
	}
	public void setEmpSalary(float empSalary) {
		EmpSalary = empSalary;
	}
}
	