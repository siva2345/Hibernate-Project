package com.hibernate.shiva;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Contract_Employee")

@AttributeOverrides({  
    @AttributeOverride(name="Salary", column=@Column(name="Salary")),  
    @AttributeOverride(name="EmployeeName", column=@Column(name="EmployeeName")),
    @AttributeOverride(name="DOJ", column=@Column(name="DOJ"))
})      
public class Contract_Employee extends Employeepojo {
	
	@Column(name="allowance")
	private int allowance;

	public int getAllowance() {
		return allowance;
	}

	public void setAllowance(int allowance) {
		this.allowance = allowance;
	}
}
