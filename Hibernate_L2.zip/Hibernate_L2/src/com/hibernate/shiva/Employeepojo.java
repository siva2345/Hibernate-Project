package com.hibernate.shiva;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

/*public class Employeepojo {

	private int EmployeeID;
	private String EmployeeName;
	private int Salary;
	private String DOJ;
	
	
	public int getEmployeeID() {
		return EmployeeID;
	}
	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getDOJ() {
		return DOJ;
	}
	public void setDOJ(String dOJ) {
		DOJ = dOJ;
	}*/
	
	@Entity
	@Table(name = "Employeetest")
	@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
	
	public class Employeepojo{
		
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO) 
		@Column(name="EmployeeID")
		private int EmployeeID;
		
		@Column(name="EmployeeName")
		private String EmployeeName;
		
		@Column(name="Salary")
		private int Salary;
		
		@Column(name="DOJ")
		private String DOJ;

		public int getEmployeeID() {
			return EmployeeID;
		}

		public void setEmployeeID(int employeeID) {
			EmployeeID = employeeID;
		}

		public String getEmployeeName() {
			return EmployeeName;
		}

		public void setEmployeeName(String employeeName) {
			EmployeeName = employeeName;
		}

		public int getSalary() {
			return Salary;
		}

		public void setSalary(int salary) {
			Salary = salary;
		}

		public String getDOJ() {
			return DOJ;
		}

		public void setDOJ(String dOJ) {
			DOJ = dOJ;
		}
		
}
