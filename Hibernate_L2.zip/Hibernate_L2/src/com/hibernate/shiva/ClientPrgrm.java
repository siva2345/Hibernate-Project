package com.hibernate.shiva;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class ClientPrgrm {

	public static void main(String[] args) {
		AnnotationConfiguration  cfg = new AnnotationConfiguration();
		
		cfg.configure("hibernate.cfg.xml"); 
		
		SessionFactory factory = cfg.buildSessionFactory();
		
		Session session = factory.openSession();
		
		Contract_Employee e1= new Contract_Employee();
		e1.setEmployeeName("Contract2");
		e1.setSalary(400000);
		e1.setDOJ("25-06-2010");
		e1.setAllowance(4000);
		
		Regular_Employee e2= new Regular_Employee();
		e2.setEmployeeName("regular2");
		e2.setSalary(400000);
		e2.setDOJ("25-06-2010");
		e2.setQplc(5000);
		
		/*Employeepojo e=new Employeepojo(); 

        e.setEmployeeName("Nagi");
        e.setSalary(2500);
        e.setDOJ("20-01-2016");*/

		
		
		Transaction tx = session.beginTransaction();
		session.save(e1);
		session.save(e2);
		tx.commit();
		session.close();
		factory.close();
	}

}
