package com.hibernate.shiva;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Regular_Employee")

@AttributeOverrides({  
    @AttributeOverride(name="Salary", column=@Column(name="Salary")),  
    @AttributeOverride(name="EmployeeName", column=@Column(name="EmployeeName")),
    @AttributeOverride(name="DOJ", column=@Column(name="DOJ"))
})  
public class Regular_Employee extends Employeepojo {
	
	@Column(name="qplc")
	private int qplc;

	public int getQplc() {
		return qplc;
	}

	public void setQplc(int qplc) {
		this.qplc = qplc;
	}
}
